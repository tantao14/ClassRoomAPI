﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassRoomAPI.Models
{
    public class PerformanceData
    {

        public string PerformanceName;

        //date
        public string PerformanceTime;


        public string PerformanceAddress;
        public string PerformanceState;
        public static string ShowOrder;
        public static int page = 1;
        public static int SelectedItem;
    }
}
